Full Content RSS Site Patterns
---------------------------

Site patterns allow you to specify what should be extracted from specific sites.